| `Version` | `Update Notes`                                                                                                  |
|-----------|-----------------------------------------------------------------------------------------------------------------|
| 1.0.4     | - Update ServerSync                                                                                             |
| 1.0.3     | - Add ability to translate the mod.<br/> - Add messages for when you're getting sick of the food you're eating. |
| 1.0.2     | - Bump for Bog Witch update.                                                                                    |
| 1.0.1     | - Bump for Ashlands.                                                                                            |
| 1.0.0     | - Initial Release                                                                                               |